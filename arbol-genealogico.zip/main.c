#include <stdio.h>
int main (){
    int Tatarabuelos,Bisabuelos,Abuelos,Papas,Hermanos,Sobrino,opcion;
      printf("Bienvenidos a mi arbol genealogico:\n");
       while(opcion!=6){
           printf("Aquien quieres conocer \n");
           printf("1.Tatarabuelos \n");
           printf("2.Bisabuelos \n");
           printf("3.Abuelos \n");
           printf("4.Papas \n");
           printf("5.Hermanos \n");
           printf("6.Sobrino \n");
           scanf("%d",&opcion);
       
    if(opcion==1){
        printf(" Vianey ordonez \n");
        printf(" Fransisco Ramirez \n");
        }
    if(opcion==2){
        printf("Carmen ordoñez \n");
        printf("cipriano Escobar \n");
         printf("Alicia Sanchez \n");
         printf("Martin Batalla \n");
    }
    if(opcion==3){
        printf("Lucia Escobar Ordoñez \n");
        printf("Maximino Batalla Sanchez \n");
        printf("Margarita Arriaga \n");
        printf("Miguel Bernabe \n");
    }
    if(opcion==4){
        printf("Maria Eugenia Batalla Escobar \n");
        printf("David Bernabe Arriaga \n");
    }
    if (opcion==5){
        printf("Maribel Bernabe Batalla \n");
        printf("Diego Bernabe Batalla \n");
        printf("Ivon Bernabe Batalla \n");
       }
    if (opcion==6){
        printf("Ian Mateo Solis Bernabe \n");

    return 0;
    }
       }
}
  